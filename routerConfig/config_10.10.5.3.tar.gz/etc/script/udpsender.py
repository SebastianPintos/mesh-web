import socket
import time

UDP_IP = "10.10.5.5"
UDP_PORT = 5006
MESSAGE = "{\"ip\":\"10.10.5.3\",\"timestamp\": \"2017-12-30T02:20:13.895426\",\"current\":2.1,\"type\":0}"

while 1:
	print ("UDP target IP:", UDP_IP)
	print ("UDP target port:", UDP_PORT)
	print ("message:", MESSAGE)

	sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # UDP
	sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
	time.sleep(10)
