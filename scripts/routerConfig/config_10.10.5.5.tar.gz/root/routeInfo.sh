echo /netjsoninfo route | nc 127.0.0.1 9001

