import socket, threading

UDP_IP = "0.0.0.0"
UDP_PORT = 5006

UDP_SERVER_PORT = 5005
UDP_SERVER_IP = "129.168.1.2"

sock_recv = socket.socket(socket.AF_INET, # Internet
                     socket.SOCK_DGRAM) # UDP
sock_recv.bind((UDP_IP, UDP_PORT))

sock_sender = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) # UDP
while True:
	data, addr = sock_recv.recvfrom(1024) # buffer size is 1024 bytes
 	print("received message:", data)
	try: 
		sock_sender.sendto(data, (UDP_SERVER_IP, UDP_SERVER_PORT)) 
	except:
		print ("Error de conexion")

